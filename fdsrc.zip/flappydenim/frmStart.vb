﻿Public Class frmStart
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles tbNick.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblAllwd.Click

    End Sub
End Class